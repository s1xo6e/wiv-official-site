# 开发说明

状态：基于当前 Demo 的操作说明，2026-10-22。历史规范已归档并适配；近生产旧代码若找回再重新比对。

## 运行和验证

Node.js >=22.13.0；依赖由 `package-lock.json` 固定，首次安装用 `npm ci`。

```bash
npm run dev
npm run dev:lan
npm run build
npm test
npx tsc --noEmit --incremental false
npm run test:repo
npm run docs:check
```

预览默认 3000 端口；内网地址由启动日志和当前网络决定。详细说明见根 README。

## 结构与修改方式

- Vinext + Vite + React，使用 Next 兼容的 App Router 接口。
- `app/` 是页面与布局，`public/assets/` 是展示素材。
- `worker/`、`build/`、`.openai/` 为现有运行和托管集成。
- `db/`、`drizzle/`、`examples/d1/` 与认证辅助代码目前未接入官网业务。
- 当前板块开始优化时，再提取相应组件、类型明确的内容数据和局部样式。
- 不编辑 `dist/` 等生成目录作为最终源码。

## 当前验证限制

2026-10-22 构建通过；官网旧模板测试 2 项失败；独立类型检查有 3 项 Cloudflare 类型错误。另有窄屏遮挡、移动导航和表单展示问题，详见 `project-assessment.md`。这些记录不能代表后续版本自动通过。

## 版本保存与协作

每个可验收单元关联一个 WIV 任务 ID，使用 `codex/` 任务分支；一个人也可用小范围 PR 核对改动与检查。工作未全部完成也应在获授权后保存并推送任务分支，避免只在任务完全结束时保存。`main` 用于已验收成果；已推送的任务分支也可用于换机接续。

```bash
npm run repo:status
npm run repo:check
```

前者只报告本地和缓存状态；后者读取当前分支的远端上游引用，只有工作区干净且远端 SHA 与本地 HEAD 一致才返回成功。它只核验当前分支，不覆盖忽略资料、其他分支和外部配置，且不会执行提交或推送。

## 环境与发布

当前没有为官网启用 D1/R2。新增服务时记录配置键名、用途及恢复方式，真实值存放在适当的密钥管理或独立安全备份中。

正式发布需核对 Site 身份、候选提交、配置、访问范围和回退版本，并记录部署结果。当前 checkout 的部署历史和旧生产候选来源尚待核对，本轮不依据早期 Demo 重建或覆盖云端版本。

## 文档维护

文档入口为 `docs/README.md`。产品决策更新 `product-definition.md`；页面关系更新 `information-architecture.md`；设计更新 `content-visual-spec.md`；素材对应与审核更新 `docs/assets/asset-registry.json`；任务变更更新 `iteration-plan.md`；阶段结束/切换项目更新 `handoff.md`。

`docs/reference-materials/` 是可入库的历史原件区，源文件不随实现改写；修改当前规则和台账时保留来源定位。`npm run docs:check` 核对来源哈希、本地资产及有效文档链接，不代替产品功能或公开授权验收。

聊天中影响后续实现的结论要落到相应文档，文档和代码一起进入版本记录。分板块新对话从 `docs/chat-start.md` 启动，不依赖当前聊天历史。
