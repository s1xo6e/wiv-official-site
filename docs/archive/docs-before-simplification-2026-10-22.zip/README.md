# 西部智车官网

当前是 wivSPACE 品牌与产品的单页 Demo。后续以高校与科研院所为首要访客，按板块确认内容、设计、实现和验收，逐步形成可用于科研、教学实训与实验室建设咨询的官网。

## 本地与内网预览

需要 Node.js >=22.13.0。已有依赖时无需重复安装；首次检出使用 `npm ci`。

```bash
npm run dev
```

本机访问 <http://localhost:3000/>。

```bash
npm run dev:lan
```

内网模式监听 `0.0.0.0`，默认端口 3000。同一局域网的手机或电脑通过 `http://本机局域网IP:3000/` 访问。2026-10-22 此电脑的 Wi-Fi 地址为 <http://192.168.1.86:3000/>；更换网络后可能变化，可用 `ipconfig getifaddr en0` 查询。以启动日志实际打印的端口为准，端口占用时开发服务器可能顺延。

预览依赖这台电脑和开发进程持续运行。若另一台设备打不开，依次检查同一 Wi-Fi/局域网、启动日志中的地址与端口、网络的设备隔离和系统防火墙的应用放行。内网预览用于协作开发，不等同于正式网站部署。

## 项目结构

```text
app/                 页面入口、布局、全局样式；当前首页在 page.tsx
public/assets/       按首页、产品、案例、关于、联系分类的品牌素材
worker/              Cloudflare Worker 入口
build/               Sites 构建与发布元数据集成源码（保留）
.openai/hosting.json  现有 Site 标识与可选存储声明（保留）
db/ + drizzle/       预留数据库能力，当前未启用
examples/d1/         未接入官网的数据库示例
tests/               当前仍是旧模板测试，需在第一轮更新
docs/                项目评估、迭代任务和基线证据
```

实际运行使用 Vinext + Vite + React，使用 Next 兼容的 App Router 接口；根目录存在 `next.config.ts` 不代表另有一套独立 Next 应用。`dist/`、`.next/`、`.vinext/`、`.wrangler/`、`node_modules/` 是忽略的构建、运行或依赖目录。

## 评估与迭代

- [文档入口与历史资料采纳记录](docs/README.md)
- [产品定义](docs/product-definition.md)
- [当前信息架构](docs/information-architecture.md)
- [当前内容与视觉规范](docs/content-visual-spec.md)
- [资产台账与维护说明](docs/assets/README.md)
- [开发说明](docs/development.md)
- [项目接续与换机核验](docs/handoff.md)
- [项目评估与现有问题](docs/project-assessment.md)
- [迭代计划、初始任务和验收规则](docs/iteration-plan.md)

三份历史开发资料已原样归档到 `docs/reference-materials/`，并适配为当前业务、设计与资产依据。代码仍是早期Demo，近生产旧代码尚未恢复；新找回的资料先比对再采用。后续原始文档/截图可放入 `project-inputs/`，完整旧项目保存在仓库外的独立目录。

分板块新对话使用 [chat-start.md](docs/chat-start.md)，通过任务ID与交接文档接续，不依赖当前聊天历史。文档基础已接入，技术质量基线修复仍是WIV-001待办。

```bash
npm run repo:status
npm run repo:check
```

第一条只读本地状态；第二条直接读取当前上游分支的远端提交，并以非零退出码提示尚未同步的情况。两者均不自动提交、推送或发布。忽略资料和外部配置另做备份；换机前进行独立 clone 恢复验证，详见交接说明。

## 验证命令与当前基线

```bash
npm run build
npm test
npx tsc --noEmit --incremental false
npm run docs:check
```

2026-10-22 本地核查：构建通过；`npm test` 的两项测试仍校验已移除的 starter skeleton，均失败；独立类型检查有三项 Cloudflare 运行时类型错误。网站可预览并不代表质量门槛已经全部通过，具体证据与待办见 `docs/`。

## 后续开发约定

预览、内容确认、功能验收与正式发布分开记录。建议每项任务关联具体板块、验收标准和变更证据，采用 `codex/` 前缀的任务分支。当前仓库内的计划是初始草案，任务负责人和未确认的业务资料需在该任务开始前明确。

保留现有 Site 身份和构建集成；发布前核对目标环境与访问范围。数据库、认证、CRM 和表单收件方式按实际需求再接入。
